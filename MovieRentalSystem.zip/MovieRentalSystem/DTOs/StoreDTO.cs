namespace MovieRentalSystem.Models
{
    public class StoreDTO
    {
        public int ManagerStaffId { get; set; }
        public int AddressId { get; set; }
    }
}
