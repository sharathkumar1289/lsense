// using AutoMapper;
// using MovieRentalSystem.DTOs;
// using MovieRentalSystem.Models;

// namespace MovieRentalSystem.Mapping
// {
//     public class MappingProfile : Profile
//     {
//         public MappingProfile()
//         {
//             // Example: Mapping Store to StoreDto
//             CreateMap<Store, StoreDTO>();
//         }
//     }
// }
