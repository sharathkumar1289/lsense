using Microsoft.EntityFrameworkCore;
using MovieRentalSystem.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MovieRentalSystem.Repositories
{
    public class StoreRepository : IStoreRepository
    {
        private readonly ApplicationDbContext _context;


        public StoreRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Store>> AddStoreAsync(Store store)
        {
            _context.Stores.Add(store);
            await _context.SaveChangesAsync();
            return await _context.Stores.Include(s => s.Address).ToListAsync();
        }
    }
}
