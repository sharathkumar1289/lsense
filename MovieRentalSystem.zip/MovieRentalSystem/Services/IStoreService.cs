using MovieRentalSystem.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MovieRentalSystem.Services
{
    public interface IStoreService
    {
        Task<List<Store>> AddStoreAsync(Store store);
    }
}
