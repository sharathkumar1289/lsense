using Microsoft.AspNetCore.Mvc;
using MovieRentalSystem.Models;
using MovieRentalSystem.Services;
using FluentValidation;

namespace MovieRentalSystem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoreController : ControllerBase
    {
        private readonly IStoreService _storeService;

        public StoreController(IStoreService storeService)
        {
            _storeService = storeService;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddStoreAsync([FromBody] StoreDTO storeDto)
        {
            if (storeDto == null)
            {
                return BadRequest("Store data is null.");
            }

            try
            {
                await _storeService.AddStoreAsync(storeDto);
                return CreatedAtAction(nameof(AddStoreAsync), new { id = storeDto.ManagerStaffId }, storeDto);
            }
            catch (ValidationException ex)
            {
                return BadRequest(new { Errors = ex.Errors.Select(e => e.ErrorMessage) });
            }
        }
    }
}
